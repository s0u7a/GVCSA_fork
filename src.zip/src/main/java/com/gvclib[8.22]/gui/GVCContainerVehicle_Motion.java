package gvclib.gui;
 

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
 
public class GVCContainerVehicle_Motion extends Container
{
    
    public GVCContainerVehicle_Motion()
    {
    }

	@Override
	public boolean canInteractWith(EntityPlayer playerIn) {
		// TODO 自動生成されたメソッド・スタブ
		return true;
	}
}